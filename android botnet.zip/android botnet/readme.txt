password - xerxes


🔰 Latest Android BotNet 🔰

🌀HQ Leak For Black Hat Pro

🔻Features:-
◾️Sms Stealer
◾️Credit Card Grabber
◾️Device Locker
◾️Contacts Stealer 
◾️SMS Sender
◾️Run Apps
◾️Flood SMS
◾️Download apps in victim phone
◾️Inject Bank pages
◾️Notification Sender