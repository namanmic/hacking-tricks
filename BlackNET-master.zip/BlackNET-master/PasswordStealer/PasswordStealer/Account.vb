Imports System
Imports System.Collections.Generic
Imports System.Text

Namespace ChromeRecovery
    Public Class Account
        Public Property UserName As String
        Public Property Password As String
        Public Property URL As String
        Public Property Application As String
    End Class
End Namespace

