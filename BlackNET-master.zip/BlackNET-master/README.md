<p align="center">
 <img src="https://b.top4top.io/p_1104t3ole1.png" alt="" />
</p>

<p align="center">
 <a href="#"><img align="center" src="https://img.shields.io/maintenance/no/2020" /></a> 
 <a href="#"><img align="center" src="https://img.shields.io/github/license/BlackHacker511/BlackNET" /></a>
 <a href="#"><img align="center" src="https://img.shields.io/github/v/release/BlackHacker511/BlackNET" /></a>
 <a href="#"><img align="center" src="https://app.fossa.com/api/projects/git%2Bgithub.com%2FBlackHacker511%2FBlackNET.svg?type=shield"/></a>
 <a href="#"><img align="center" src="http://isitmaintained.com/badge/resolution/BlackHacker511/BlackNET.svg" /></a>
</p>

# BlackNET
Free advanced and modern Windows botnet with a nice and secure PHP panel developed using VB.NET.

## About BlackNET
Free advanced and modern Windows botnet with a nice and secure PHP panel developed using VB.NET.

this botnet controller comes with a lot of features and the most secure panel for free

Developed By: Black.Hacker

## What You Can Do
 1. Upload File
 2. DDOS Attack [ TCP,UDP,ARME,Slowloris, HTTPGet, POSTHttp, Bandwidth Flood ]
    + Start DDOS
    + Stop DDOS
 3. Open Webpage
     + Visible
     + Hidden
 4. Show MessageBox
 5. Take Screenshot
 6. Steal Firefox Cookies
 7. Steal Saved Passwords
 8. Keylogger
 9. Execute Scripts
10. Computer Operations
    + Restart
    + Shutdown
    + Logout
11. Bitcoint Wallet Stealer
12. Uninstall Client
13. Move Client
14. Blacklist Client
15. Update Client
16. Close Client
 
## Requirements
1. PHP >=  7.0
    + cURL
    + php_cURL
2. NET Framework
    + Stub >= 2.0
    + Builder >= 4.0

## How to Install PHP Panel
1. Clone this Repo
2. Compress BlackNET panel folder and upload it to your hosting
3. Create a database with any name you want
4. Change the data in classes/Database.php
5. Change files and folders permission to 777 [ Uploads Folder, Scripts Folder ]
6. Go to install.php to create the botnet tables automatically

## Screenshots
![Installtion Page](https://i.gyazo.com/e833393d7e3cf126347a9633a8fa5cd0.png)

![Image of Login Page](https://b.top4top.io/p_1482shh7l1.png)

![Image of the interface](https://j.top4top.io/p_1596pvgt71.png)

![Image of the Builder](https://i.gyazo.com/b65371110336ebbb2faa42ff5f68f95e.png)

## Stub Scan Result

<img src="https://j.top4top.io/p_1596ty0571.png" alt="stub.exe scan result" width="340" hieght="775" />

## YouTube Tutorials
[How to install BlackNET v2.0](https://www.youtube.com/watch?v=ReKOuh6fFcQ)

[How to update BlackNET to v2.5](https://youtu.be/07XioeJvPZk)

[How to obfuscate BlackNET](https://www.youtube.com/watch?v=hzC8_UYGor0)

[How to Setup BlackNET Cron Job System](https://www.youtube.com/watch?v=rHCYGRA1h54)

## What's New

````
v3.5 😈
 + Added Client Location Information
 + Added Discord Token Stealer
 + Added Panel Version in WebUI
 + Added Send Spam Email Function
 + Added Chrome History Stealer
 + Added Bruteforce Protection
 + Added Custom Plugin System
   + Create your own custom commandS
 + Added a new Panel Install System
 + Added Export Logs to CSV Function
 + Added New Job File
   + remove.php | Remove Offline Clients
 + Enabled Client Sorting
 + Fixed Upload & Execute Bug
 + Fixed Password Stealer Plugin
 + Fixed Check Update Bug
 + Fixed DDoS Bug
 + Fixed [ Send Command ] Issues
 + Removed ConfuserEx Support
 + Removed Client Update
   + Crashes the client
   + Trigers Issues
 + Better Blacklisting
 + Better TEMP Cleaner
 + Better Plugin Handling
 + Replace RSA with AES-128
 + Improved HTTP Socket
 + More Client Information
   + Client Version
   + Client HWID
 + Update BlackUpload to v2.0
   + New Code
   + Bug Fixes
   + Better Security
   + And More
 + Better Performance
 + Stable Connection
 + Better Client Handling
 + Better Speed
 + Miner code changes
 + Security Enhancements
 + UI Enhancements
 + Bugs Fixed
````

## Pull Request
1. Fork the repo
2. Add your feature
3. Create a pull request

i will review it in 1 - 5 days then i will merge it with the master branch

## Thanks to
- KFC
- NYAN CAT
- omerfademir

## Python Edition
[BlackHacker511/BlackNET-Python](http://github.com/BlackHacker511/BlackNET-Python)

## LEGAL DISCLAIMER PLEASE READ!
##### I, the creator and all those associated with the development and production of this program are not responsible for any actions and or damages caused by this software. You bear the full responsibility of your actions and acknowledge that this software was created for educational purposes only. This software's intended purpose is NOT to be used maliciously, or on any system that you do not have own or have explicit permission to operate and use this program on. By using this software, you automatically agree to the above.

## License
This project is licensed under the MIT License

[![FOSSA Status](https://app.fossa.io/api/projects/git%2Bgithub.com%2FBlackHacker511%2FBlackNET.svg?type=large)](https://app.fossa.io/projects/git%2Bgithub.com%2FBlackHacker511%2FBlackNET?ref=badge_large)

## Copyright
[![Open Source Love svg1](https://badges.frapsoft.com/os/v1/open-source.png?v=103)](https://github.com/ellerbrock/open-source-badges/) 

Copyright © Black.Hacker - 2020
