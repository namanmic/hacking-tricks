﻿Public Class Plugin
    Public Function Run() ' Important Function
        MsgBox("This is my plugin")
    End Function
End Class